//
//  ViewController.h
//  flux.beta
//
//  Created by Michael Herf on 10/13/15.
//  Copyright © 2015 f.lux Software LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

